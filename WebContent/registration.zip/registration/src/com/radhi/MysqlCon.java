package com.radhi;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

class MysqlCon {
	/*public static void main(String args[]) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rk", "root", "root");
//here sonoo is database name, root is username and password  
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from student");
			while (rs.next())
				System.out.println(rs.getInt(1) + "  " + rs.getString(2)+" "+rs.getString(3)); 
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}*/
	public Connection getConnection()
	{
		Connection con=null ;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rk", "root", "root");
			 return con;
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
		}
	public String saveDetails(String fname,String lname,int id,String phno,String branch)
	{
		boolean boo=false;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			 Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rk", "root", "root");
			PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?,?,?)");
			ps.setString(1,fname);
			ps.setString(2,lname);
			ps.setString(3,id);
			ps.setString(4, phno);
			ps.setString(5,branch);
			boo=ps.execute();
			ps.close();
			con.close();
			return "s";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "n";
	}
	public ArrayList<Student> studentlist()
	{
		ArrayList<Student> al=new ArrayList<Student>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rk", "root", "root");
//here sonoo is database name, root is username and password  
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from student");
			while (rs.next())
			{
				Student s=new Student();
				s.setfname(rs.getString(1));
				s.setlname(rs.getString(2));
				s.setSid(rs.getInt(3));
				s.setPhno(rs.getString(4));
				s.setbranch(rs.getString(5));
				al.add(s);
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return al;
	}
}
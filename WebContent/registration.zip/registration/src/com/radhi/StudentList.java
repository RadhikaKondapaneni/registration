package com.radhi;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentList
 */
@WebServlet("/StudentList")
public class StudentList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		MysqlCon fix=new MysqlCon();
		ArrayList<Student> al=fix.studentlist();
		PrintWriter out=response.getWriter();//get the stream to write the data  
		out.println("<html><body>");  
		out.print("<table border='1' width='100%'");  
        out.print("<tr><th>fname</th><th>lname</th><th>id</th><th>phno</th><th>branch</th></tr>");  
        for(Student e:al){  
         out.print("<tr><td>"+e.getfname()+"</td><td>"+e.getlname()+"</td><td>"+e.getSid()+"</td><td>"+e.getPhno()+"</td><td>"+e.getbranch()"</td></tr>");
        }  
        out.print("</table>");  
		out.println("</body></html>");
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
